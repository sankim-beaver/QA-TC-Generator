"""Tkinter 데스크톱 UI."""
import queue
import threading
import traceback
import webbrowser
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

from . import __version__, pipeline
from .config import CONFIG_PATH, Settings

FIELDS = [
    ("asana_pat", "Asana 개인 액세스 토큰 *", True),
    ("anthropic_api_key", "Claude API 키 *", True),
    ("figma_token", "Figma 개인 액세스 토큰 (선택)", True),
    ("spreadsheet", "TC 스프레드시트 URL *", False),
    ("template_sheet", "복제할 템플릿 탭 이름", False),
    ("list_sheet", "목차(List) 탭 이름", False),
    ("claude_model", "Claude 모델명", False),
    ("max_tokens", "최대 출력 토큰", False),
]


class SettingsDialog(tk.Toplevel):
    def __init__(self, master, settings: Settings):
        super().__init__(master)
        self.title("설정")
        self.settings = settings
        self.vars: dict[str, tk.StringVar] = {}
        self.resizable(False, False)
        frm = ttk.Frame(self, padding=12)
        frm.pack(fill="both", expand=True)

        for r, (key, label, secret) in enumerate(FIELDS):
            ttk.Label(frm, text=label).grid(row=r, column=0, sticky="w", pady=3)
            var = tk.StringVar(value=str(getattr(settings, key)))
            ttk.Entry(frm, textvariable=var, width=52, show="•" if secret else "").grid(row=r, column=1, columnspan=2, pady=3)
            self.vars[key] = var

        r = len(FIELDS)
        ttk.Label(frm, text="Google OAuth 클라이언트 JSON *").grid(row=r, column=0, sticky="w", pady=3)
        self.vars["google_client_secret"] = tk.StringVar(value=settings.google_client_secret)
        ttk.Entry(frm, textvariable=self.vars["google_client_secret"], width=40).grid(row=r, column=1, pady=3)
        ttk.Button(frm, text="찾기", command=self._pick).grid(row=r, column=2, padx=4)

        ttk.Label(frm, text=f"저장 위치: {CONFIG_PATH}", foreground="gray").grid(row=r + 1, column=0, columnspan=3, sticky="w", pady=(8, 0))
        btns = ttk.Frame(frm)
        btns.grid(row=r + 2, column=0, columnspan=3, sticky="e", pady=(10, 0))
        ttk.Button(btns, text="취소", command=self.destroy).pack(side="right", padx=4)
        ttk.Button(btns, text="저장", command=self._save).pack(side="right")
        self.grab_set()

    def _pick(self):
        path = filedialog.askopenfilename(title="OAuth 클라이언트 JSON 선택", filetypes=[("JSON", "*.json")])
        if path:
            self.vars["google_client_secret"].set(path)

    def _save(self):
        for key, var in self.vars.items():
            value = var.get().strip()
            setattr(self.settings, key, int(value) if key == "max_tokens" and value.isdigit() else value)
        self.settings.save()
        self.destroy()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"QA TC Generator v{__version__}")
        self.geometry("760x560")
        self.settings = Settings.load()
        self.q: queue.Queue = queue.Queue()
        self.result_url = None

        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")
        ttk.Label(top, text="Asana 태스크 링크").pack(anchor="w")
        self.url_var = tk.StringVar()
        ttk.Entry(top, textvariable=self.url_var).pack(fill="x", pady=4)

        row = ttk.Frame(top)
        row.pack(fill="x")
        self.figma_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(row, text="Figma 데이터 포함", variable=self.figma_var).pack(side="left")
        ttk.Button(row, text="설정", command=self.open_settings).pack(side="right")
        self.open_btn = ttk.Button(row, text="시트 열기", command=self.open_sheet, state="disabled")
        self.open_btn.pack(side="right", padx=4)
        self.run_btn = ttk.Button(row, text="TC 생성", command=self.start)
        self.run_btn.pack(side="right")

        self.log = scrolledtext.ScrolledText(self, height=24, state="disabled", wrap="word")
        self.log.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        if self.settings.missing():
            self.after(300, self.open_settings)
        self.after(100, self._drain)

    def write(self, msg: str):
        self.q.put(msg)

    def _drain(self):
        while not self.q.empty():
            msg = self.q.get()
            self.log.configure(state="normal")
            self.log.insert("end", msg + "\n")
            self.log.see("end")
            self.log.configure(state="disabled")
        self.after(100, self._drain)

    def open_settings(self):
        SettingsDialog(self, self.settings)

    def open_sheet(self):
        if self.result_url:
            webbrowser.open(self.result_url)

    def start(self):
        url = self.url_var.get().strip()
        if not url:
            messagebox.showwarning("입력 필요", "Asana 태스크 링크를 입력하세요.")
            return
        if self.settings.missing():
            messagebox.showwarning("설정 필요", "설정에서 필수 항목(*)을 입력하세요.")
            self.open_settings()
            return
        self.run_btn.configure(state="disabled")
        self.open_btn.configure(state="disabled")
        threading.Thread(target=self._worker, args=(url,), daemon=True).start()

    def _worker(self, url: str):
        try:
            self.write("=" * 60)
            res = pipeline.run(self.settings, url, self.figma_var.get(), self.write)
            self.result_url = res["url"]
            self.write(f"\n완료: '{res['sheet_title']}' 탭에 TC {res['count']}건 작성")
            self.write(f"링크: {res['url']}")
            if res["summary"]:
                self.write(f"\n기능 요약: {res['summary']}")
            if res["open_questions"]:
                self.write("\n기획 확인 필요 사항:")
                for i, q in enumerate(res["open_questions"], 1):
                    self.write(f"  {i}. {q}")
            self.after(0, lambda: self.open_btn.configure(state="normal"))
        except Exception as e:
            self.write(f"\n오류: {e}")
            self.write(traceback.format_exc())
        finally:
            self.after(0, lambda: self.run_btn.configure(state="normal"))


def main():
    App().mainloop()
