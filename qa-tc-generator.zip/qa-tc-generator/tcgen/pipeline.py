"""Asana 링크 하나로 전체 작업을 수행한다."""
from . import asana, figma, generator, sheets
from .config import GOOGLE_TOKEN_PATH, Settings


def run(settings: Settings, asana_url: str, use_figma: bool = True, log=print) -> dict:
    missing = settings.missing()
    if missing:
        raise RuntimeError("설정이 비어 있습니다: " + ", ".join(missing))

    log("1/5 Google 스프레드시트 연결")
    gc = sheets.connect(settings.google_client_secret, GOOGLE_TOKEN_PATH)
    book = sheets.TcWorkbook(gc, settings.spreadsheet_id, settings.template_sheet, settings.list_sheet)
    tpl_header, tpl_rows = book.template_sample()
    log(f"  템플릿 '{settings.template_sheet}' 샘플 {len(tpl_rows)}행")

    log("2/5 Asana 태스크 읽기")
    gid = asana.parse_task_gid(asana_url)
    bundle = asana.AsanaClient(settings.asana_pat).fetch_task_bundle(gid, log)

    figma_ctxs = []
    if use_figma and settings.figma_token:
        log("3/5 Figma 읽기")
        urls = figma.extract_urls(
            bundle["notes"],
            "\n".join(v for _, v in bundle["custom_fields"]),
            "\n".join(c["text"] for c in bundle["comments"]),
        )
        if not urls:
            log("  Figma 링크 없음 → Asana 내용으로 추론해 작성")
        client = figma.FigmaClient(settings.figma_token)
        image_budget = figma.MAX_IMAGES
        for u in urls:
            try:
                ctx = client.build_context(u, image_budget, log)
                image_budget -= len(ctx["images"])
                figma_ctxs.append(ctx)
            except Exception as e:
                log(f"  Figma 읽기 실패({u[:60]}...): {e}")
    else:
        log("3/5 Figma 건너뜀(토큰 없음 또는 사용 안 함)")

    log("4/5 Claude로 TC 생성 중 (1~3분 걸릴 수 있어요)")
    content = generator.build_content(bundle, figma_ctxs, tpl_header, tpl_rows)
    result = generator.generate(settings.anthropic_api_key, settings.claude_model, settings.max_tokens, content)
    log(f"  TC {len(result['test_cases'])}건 생성")

    log("5/5 시트 작성 및 List 등록")
    ws = book.create_tc_tab(result["sheet_title"], result["test_cases"])
    list_row = book.register_in_list(ws, asana_url.strip())
    url = book.tab_url(ws)
    log(f"  '{ws.title}' 탭 생성, List {list_row}행 등록 완료")

    return {
        "sheet_title": ws.title,
        "url": url,
        "count": len(result["test_cases"]),
        "summary": result.get("feature_summary", ""),
        "open_questions": result.get("open_questions", []),
    }
