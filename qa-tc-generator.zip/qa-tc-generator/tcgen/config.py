"""사용자 설정 저장/로드. Windows에서는 %APPDATA%\\QA-TC-Generator\\config.json 에 저장된다."""
import json
import os
import re
from dataclasses import asdict, dataclass, fields
from pathlib import Path

APP_NAME = "QA-TC-Generator"


def app_dir() -> Path:
    base = os.getenv("APPDATA") or str(Path.home() / ".config")
    path = Path(base) / APP_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


CONFIG_PATH = app_dir() / "config.json"
GOOGLE_TOKEN_PATH = app_dir() / "google_token.json"


@dataclass
class Settings:
    asana_pat: str = ""
    figma_token: str = ""                 # 비워두면 Figma 단계는 건너뜀
    anthropic_api_key: str = ""
    claude_model: str = "claude-sonnet-4-5"
    max_tokens: int = 32000
    spreadsheet: str = ""                 # 스프레드시트 URL 또는 ID
    template_sheet: str = "문자전송자격인증"  # 복제할 TC 양식 탭 이름
    list_sheet: str = "List"              # 목차 탭 이름
    google_client_secret: str = ""        # Google OAuth 데스크톱 클라이언트 JSON 경로

    REQUIRED = ("asana_pat", "anthropic_api_key", "spreadsheet", "google_client_secret")

    @classmethod
    def load(cls) -> "Settings":
        if CONFIG_PATH.exists():
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            known = {f.name for f in fields(cls)}
            return cls(**{k: v for k, v in data.items() if k in known})
        return cls()

    def save(self) -> None:
        CONFIG_PATH.write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8")

    def missing(self) -> list[str]:
        return [name for name in self.REQUIRED if not str(getattr(self, name)).strip()]

    @property
    def spreadsheet_id(self) -> str:
        m = re.search(r"/spreadsheets/d/([A-Za-z0-9_-]+)", self.spreadsheet)
        return m.group(1) if m else self.spreadsheet.strip()
