"""수집한 자료로 Claude API를 호출해 TC(JSON)를 받는다."""
import anthropic

from .prompts import SYSTEM_PROMPT, TC_TOOL


def _rows_to_text(header: list[str], rows: list[list[str]]) -> str:
    lines = [" | ".join(header)]
    for r in rows:
        lines.append(" | ".join(c.replace("\n", "⏎") for c in r))
    return "\n".join(lines)


def build_content(bundle: dict, figma_ctxs: list[dict], tpl_header: list[str], tpl_rows: list[list[str]]) -> list[dict]:
    content: list[dict] = [{
        "type": "text",
        "text": "<tc_template>\n" + _rows_to_text(tpl_header, tpl_rows) + "\n</tc_template>",
        "cache_control": {"type": "ephemeral"},
    }]

    cf = "\n".join(f"- {k}: {v}" for k, v in bundle["custom_fields"])
    subs = "\n".join(f"- {s['name']} ({s['assignee']}, {'완료' if s['done'] else '진행중'})" for s in bundle["subtasks"])
    comments = "\n\n".join(f"[{c['at']} {c['by']}]\n{c['text']}" for c in bundle["comments"])
    content.append({"type": "text", "text": (
        "<asana_task>\n"
        f"제목: {bundle['name']}\n프로젝트: {bundle['projects']}\n담당: {bundle['assignee']}\n"
        f"커스텀 필드:\n{cf}\n\n본문:\n{bundle['notes']}\n\n서브태스크:\n{subs}\n"
        "</asana_task>\n\n"
        f"<asana_comments>\n{comments or '(댓글 없음)'}\n</asana_comments>"
    )})

    for name, text in bundle["text_attachments"]:
        content.append({"type": "text", "text": f'<attachment name="{name}">\n{text}\n</attachment>'})
    if bundle["other_attachments"]:
        content.append({"type": "text", "text": "읽지 못한 첨부(이름만): " + ", ".join(bundle["other_attachments"])})
    for name, media_type, b64 in bundle["images"]:
        content.append({"type": "text", "text": f"[Asana 첨부 이미지: {name}]"})
        content.append({"type": "image", "source": {"type": "base64", "media_type": media_type, "data": b64}})

    if figma_ctxs:
        for i, fc in enumerate(figma_ctxs, 1):
            content.append({"type": "text", "text": f'<figma index="{i}" name="{fc["name"]}" url="{fc["url"]}">\n{fc["tree"]}\n</figma>'})
            for name, media_type, b64 in fc["images"]:
                content.append({"type": "text", "text": f"[{name}]"})
                content.append({"type": "image", "source": {"type": "base64", "media_type": media_type, "data": b64}})
    else:
        content.append({"type": "text", "text": "<figma>없음. Asana 내용으로 추론해 작성하고 근거 없는 기대결과에는 [추정]을 붙일 것.</figma>"})

    content.append({"type": "text", "text": "위 자료로 TC를 작성해 submit_test_cases 도구로 제출하세요."})
    return content


def generate(api_key: str, model: str, max_tokens: int, content: list[dict]) -> dict:
    client = anthropic.Anthropic(api_key=api_key)
    # 출력이 길어서 스트리밍으로 받는다(장시간 요청 타임아웃 방지)
    with client.messages.stream(
        model=model,
        max_tokens=max_tokens,
        system=SYSTEM_PROMPT,
        tools=[TC_TOOL],
        tool_choice={"type": "tool", "name": "submit_test_cases"},
        messages=[{"role": "user", "content": content}],
    ) as stream:
        msg = stream.get_final_message()

    if msg.stop_reason == "max_tokens":
        raise RuntimeError("응답이 길이 제한에서 잘렸습니다. 설정에서 max_tokens를 늘려 다시 실행하세요.")
    for block in msg.content:
        if block.type == "tool_use":
            return block.input
    raise RuntimeError("Claude 응답에 TC 데이터가 없습니다.")
