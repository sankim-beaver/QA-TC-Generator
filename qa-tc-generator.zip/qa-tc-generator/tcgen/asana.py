"""Asana 태스크 본문, 커스텀 필드, 서브태스크, 댓글, 첨부파일을 수집한다."""
import base64
import io
import re
import zipfile

import requests

API = "https://app.asana.com/api/1.0"
TEXT_EXT = (".md", ".txt", ".csv", ".json", ".sql", ".yaml", ".yml")
IMAGE_TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
               ".gif": "image/gif", ".webp": "image/webp"}
MAX_TEXT_ATTACHMENT = 60_000      # 첨부 1개당 최대 글자 수
MAX_IMAGES = 5
MAX_IMAGE_BYTES = 3_500_000


def parse_task_gid(url_or_gid: str) -> str:
    s = url_or_gid.strip()
    for pattern in (r"/task/(\d+)", r"/(\d{10,})/f\b", r"/(\d{10,})/?(?:\?|$)", r"^(\d{10,})$"):
        m = re.search(pattern, s)
        if m:
            return m.group(1)
    raise ValueError(f"Asana 태스크 링크에서 태스크 ID를 찾지 못했습니다: {s}")


def docx_to_text(data: bytes) -> str:
    """python-docx 없이 .docx 본문 텍스트만 추출."""
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        xml = z.read("word/document.xml").decode("utf-8", errors="ignore")
    xml = re.sub(r"</w:p>", "\n", xml)
    return re.sub(r"<[^>]+>", "", xml)


class AsanaClient:
    def __init__(self, pat: str):
        self.s = requests.Session()
        self.s.headers["Authorization"] = f"Bearer {pat}"

    def _get(self, path: str, **params):
        r = self.s.get(f"{API}{path}", params=params, timeout=60)
        if r.status_code == 401:
            raise RuntimeError("Asana 인증 실패: 개인 액세스 토큰(PAT)을 확인하세요.")
        r.raise_for_status()
        return r.json()["data"]

    def fetch_task_bundle(self, gid: str, log=print) -> dict:
        task = self._get(
            f"/tasks/{gid}",
            opt_fields="name,notes,permalink_url,created_at,assignee.name,projects.name,"
                       "custom_fields.name,custom_fields.display_value",
        )
        log(f"  태스크: {task['name']}")

        subtasks = self._get(f"/tasks/{gid}/subtasks", opt_fields="name,notes,completed,assignee.name")
        stories = self._get(f"/tasks/{gid}/stories", opt_fields="type,text,created_by.name,created_at")
        comments = [
            {"by": (c.get("created_by") or {}).get("name", "시스템"), "at": c["created_at"][:10], "text": c["text"]}
            for c in stories if c.get("type") == "comment" and c.get("text", "").strip()
        ]
        log(f"  서브태스크 {len(subtasks)}개, 댓글 {len(comments)}개")

        attachments = self._get(f"/tasks/{gid}/attachments", opt_fields="name,download_url")
        texts, images, others = [], [], []
        for a in attachments:
            name, url = a.get("name") or "", a.get("download_url")
            lower = name.lower()
            if not url:
                others.append(name)
                continue
            try:
                if lower.endswith(TEXT_EXT):
                    body = requests.get(url, timeout=60).content.decode("utf-8", errors="ignore")
                    texts.append((name, body[:MAX_TEXT_ATTACHMENT]))
                elif lower.endswith(".docx"):
                    body = docx_to_text(requests.get(url, timeout=60).content)
                    texts.append((name, body[:MAX_TEXT_ATTACHMENT]))
                elif lower.endswith(tuple(IMAGE_TYPES)) and len(images) < MAX_IMAGES:
                    data = requests.get(url, timeout=60).content
                    if len(data) <= MAX_IMAGE_BYTES:
                        ext = "." + lower.rsplit(".", 1)[-1]
                        images.append((name, IMAGE_TYPES[ext], base64.b64encode(data).decode()))
                else:
                    others.append(name)
            except Exception as e:  # 첨부 하나 실패로 전체를 멈추지 않음
                log(f"  첨부 '{name}' 읽기 실패: {e}")
        log(f"  첨부: 문서 {len(texts)}개, 이미지 {len(images)}개, 기타 {len(others)}개")

        return {
            "gid": gid,
            "name": task["name"],
            "notes": task.get("notes", ""),
            "permalink": task.get("permalink_url", ""),
            "assignee": (task.get("assignee") or {}).get("name", ""),
            "projects": ", ".join(p["name"] for p in task.get("projects", [])),
            "custom_fields": [(f["name"], f["display_value"]) for f in task.get("custom_fields", [])
                              if f.get("display_value")],
            "subtasks": [{"name": s["name"], "done": s.get("completed"),
                          "assignee": (s.get("assignee") or {}).get("name", "")} for s in subtasks],
            "comments": comments,
            "text_attachments": texts,
            "images": images,
            "other_attachments": others,
        }
