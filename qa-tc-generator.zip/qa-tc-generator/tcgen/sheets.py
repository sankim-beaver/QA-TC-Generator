"""Google Sheets: 템플릿 탭 복제 → TC 작성 → List 탭에 기능명/Asana 링크 등록."""
import re

import gspread

SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]
IMPORTANCE = "☆☆☆☆☆"
FIRST_ROW = 5          # 템플릿: 4행이 헤더, 5행부터 데이터 (B~N열)


def connect(client_secret_path: str, token_path) -> gspread.Client:
    """처음 실행 시 브라우저가 열리고 본인 Google 계정으로 로그인한다. 이후에는 저장된 토큰을 사용."""
    return gspread.oauth(scopes=SCOPES, credentials_filename=client_secret_path,
                         authorized_user_filename=str(token_path))


def safe_title(title: str, existing: set[str]) -> str:
    base = re.sub(r"[\[\]\*\?/\\:]", "", title).strip()[:90] or "새 TC"
    name, n = base, 2
    while name in existing:
        name, n = f"{base}_{n}", n + 1
    return name


def tc_rows(test_cases: list[dict]) -> list[list]:
    rows = []
    for i, tc in enumerate(test_cases, 1):
        rows.append([
            i, tc.get("category", ""), tc.get("item", ""), tc.get("description", ""),
            tc.get("precondition", ""), tc.get("depth1", ""), tc.get("depth2", ""), tc.get("depth3", ""),
            tc.get("expected", ""), IMPORTANCE, "", "", tc.get("note", ""),
        ])
    return rows


class TcWorkbook:
    def __init__(self, gc: gspread.Client, spreadsheet_id: str, template_name: str, list_name: str):
        self.sh = gc.open_by_key(spreadsheet_id)
        self.template = self.sh.worksheet(template_name)
        self.list_ws = self.sh.worksheet(list_name)

    def template_sample(self, max_rows: int = 25) -> tuple[list[str], list[list[str]]]:
        values = self.template.get(f"B4:N{4 + max_rows}")
        header = values[0] if values else []
        rows = [r for r in values[1:] if any(c.strip() for c in r)]
        return header, rows

    def create_tc_tab(self, title: str, test_cases: list[dict]) -> gspread.Worksheet:
        existing = {ws.title for ws in self.sh.worksheets()}
        name = safe_title(title, existing)
        ws = self.sh.duplicate_sheet(
            source_sheet_id=self.template.id,
            insert_sheet_index=len(existing),
            new_sheet_name=name,
        )
        ws.batch_clear([f"B{FIRST_ROW}:N{ws.row_count}"])
        rows = tc_rows(test_cases)
        need = FIRST_ROW + len(rows) + 5
        if need > ws.row_count:
            ws.add_rows(need - ws.row_count)
        ws.update(range_name=f"B{FIRST_ROW}", values=rows, value_input_option="RAW")
        ws.update(range_name="C2", values=[[name]], value_input_option="RAW")
        return ws

    def register_in_list(self, ws: gspread.Worksheet, asana_url: str) -> int:
        """List 탭에서 번호(B)는 있고 기능명(D)이 빈 첫 행에 등록. 없으면 마지막 다음 행에 추가."""
        values = self.list_ws.get(f"B1:D{self.list_ws.row_count}")
        target_row, last_no, last_row = None, 0, 0
        for idx, row in enumerate(values, 1):
            b = (row[0] if row else "").strip()
            d = (row[2] if len(row) > 2 else "").strip()
            if b.isdigit():
                last_no, last_row = max(last_no, int(b)), idx
                if not d and target_row is None:
                    target_row = idx
        if target_row is None:
            target_row = last_row + 1
            if target_row > self.list_ws.row_count:
                self.list_ws.add_rows(10)
            self.list_ws.update(range_name=f"B{target_row}", values=[[last_no + 1]], value_input_option="RAW")

        def linked(text, uri):
            return {"userEnteredValue": {"stringValue": text},
                    "userEnteredFormat": {"horizontalAlignment": "CENTER", "textFormat": {"link": {"uri": uri}}}}

        self.sh.batch_update({"requests": [{"updateCells": {
            "start": {"sheetId": self.list_ws.id, "rowIndex": target_row - 1, "columnIndex": 3},
            "fields": "userEnteredValue,userEnteredFormat.textFormat.link,userEnteredFormat.horizontalAlignment",
            "rows": [{"values": [linked(ws.title, f"#gid={ws.id}"), linked("링크", asana_url)]}],
        }}]})
        return target_row

    def tab_url(self, ws: gspread.Worksheet) -> str:
        return f"https://docs.google.com/spreadsheets/d/{self.sh.id}/edit#gid={ws.id}"
