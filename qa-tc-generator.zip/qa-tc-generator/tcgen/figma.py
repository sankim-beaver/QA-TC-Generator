"""Figma 링크를 찾아 화면 구조(프레임명, 컴포넌트, 실제 문구)를 텍스트로 압축하고 주요 화면을 PNG로 렌더링한다."""
import base64
import re
from urllib.parse import parse_qs, unquote, urlparse

import requests

API = "https://api.figma.com/v1"
URL_RE = re.compile(r"https://(?:www\.)?figma\.com/(?:file|design|proto|board)/[A-Za-z0-9]+[^\s\"'<>)\]]*")
SKIP_TYPES = {"VECTOR", "BOOLEAN_OPERATION", "LINE", "ELLIPSE", "STAR", "REGULAR_POLYGON", "RECTANGLE"}
GENERIC_NAME = re.compile(r"^(Frame|Group|Rectangle|Vector|Ellipse|Line|image|Union|Mask)\s*\d*$", re.I)
MAX_LINKS = 4
MAX_TREE_CHARS = 40_000
MAX_IMAGES = 4


def extract_urls(*texts: str) -> list[str]:
    seen, out = set(), []
    for text in texts:
        for u in URL_RE.findall(text or ""):
            u = unquote(u.replace("&amp;", "&"))
            key = _parse(u)
            if key not in seen:
                seen.add(key)
                out.append(u)
    return out[:MAX_LINKS]


def _parse(url: str) -> tuple[str, str | None]:
    p = urlparse(url)
    file_key = p.path.split("/")[2]
    node = parse_qs(p.query).get("node-id", [None])[0]
    return file_key, (node.replace("-", ":") if node else None)


def _walk(node: dict, depth: int, lines: list[str], frames: list[str]) -> None:
    t, name = node.get("type"), (node.get("name") or "").strip()
    if t in SKIP_TYPES or node.get("visible") is False:
        return
    pad = "  " * min(depth, 12)
    if t == "TEXT":
        txt = (node.get("characters") or "").replace("\n", " / ").strip()
        if txt:
            lines.append(f'{pad}- "{txt}"')
    elif t in ("FRAME", "SECTION", "COMPONENT", "COMPONENT_SET", "INSTANCE", "STICKY", "SHAPE_WITH_TEXT"):
        if name and not GENERIC_NAME.match(name):
            lines.append(f"{pad}[{t}] {name}")
        if t == "FRAME" and depth == 1:
            frames.append(node["id"])
        if t in ("STICKY", "SHAPE_WITH_TEXT"):  # FigJam 메모
            txt = (node.get("characters") or "").strip()
            if txt:
                lines.append(f'{pad}  메모: "{txt}"')
    for child in node.get("children", []):
        _walk(child, depth + 1, lines, frames)


class FigmaClient:
    def __init__(self, token: str):
        self.s = requests.Session()
        self.s.headers["X-Figma-Token"] = token

    def build_context(self, url: str, want_images: int, log=print) -> dict:
        file_key, node_id = _parse(url)
        if node_id:
            r = self.s.get(f"{API}/files/{file_key}/nodes", params={"ids": node_id}, timeout=180)
            r.raise_for_status()
            data = r.json()
            roots = [v["document"] for v in data["nodes"].values() if v]
        else:
            r = self.s.get(f"{API}/files/{file_key}", params={"depth": 3}, timeout=180)
            r.raise_for_status()
            data = r.json()
            roots = data["document"]["children"]
        lines, frames = [], []
        for root in roots:
            _walk(root, 0, lines, frames)
        tree = "\n".join(lines)
        if len(tree) > MAX_TREE_CHARS:
            tree = tree[:MAX_TREE_CHARS] + "\n...(이하 생략)"
        log(f"  Figma '{data.get('name', file_key)}': 텍스트 {len(tree):,}자, 하위 화면 {len(frames)}개")

        images = []
        if want_images > 0 and frames:
            ids = frames[:want_images]
            r = self.s.get(f"{API}/images/{file_key}",
                           params={"ids": ",".join(ids), "format": "png", "scale": 0.5}, timeout=180)
            if r.ok:
                for nid, img_url in (r.json().get("images") or {}).items():
                    if img_url:
                        png = requests.get(img_url, timeout=120).content
                        if len(png) < 3_500_000:
                            images.append((f"Figma 화면 {nid}", "image/png", base64.b64encode(png).decode()))
        return {"url": url, "name": data.get("name", file_key), "tree": tree, "images": images}
