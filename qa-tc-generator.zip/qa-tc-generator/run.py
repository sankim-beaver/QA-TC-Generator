"""실행 진입점.

GUI:  python run.py
CLI:  python run.py --cli <Asana 태스크 링크> [--no-figma]
"""
import sys


def cli(argv: list[str]) -> None:
    from tcgen import pipeline
    from tcgen.config import Settings

    urls = [a for a in argv if not a.startswith("--")]
    if not urls:
        print("사용법: python run.py --cli <Asana 태스크 링크> [--no-figma]")
        sys.exit(1)
    res = pipeline.run(Settings.load(), urls[0], use_figma="--no-figma" not in argv)
    print(f"\n완료: {res['sheet_title']} / TC {res['count']}건\n{res['url']}")
    for i, q in enumerate(res["open_questions"], 1):
        print(f"  확인필요 {i}. {q}")


if __name__ == "__main__":
    if "--cli" in sys.argv:
        cli(sys.argv[1:])
    else:
        from tcgen.app import main
        main()
