@echo off
REM Build the exe on your own Windows PC. Requires Python 3.10+.
python -m venv .venv
call .venv\Scripts\activate
pip install -r requirements.txt pyinstaller
pyinstaller --noconfirm --onefile --windowed --name QA-TC-Generator run.py
echo.
echo Done: dist\QA-TC-Generator.exe
pause
