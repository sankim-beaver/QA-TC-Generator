# QA TC Generator

Asana 태스크 링크 하나로 **QA 테스트 케이스 초안을 자동 작성**하는 Windows 데스크톱 프로그램입니다.

1. Asana 태스크의 본문, 커스텀 필드, 서브태스크, **댓글 전체**, 첨부 문서(.md/.txt/.docx)와 이미지를 읽습니다.
2. 태스크와 댓글에 있는 Figma 링크를 찾아 화면 구조와 문구를 읽고, 주요 화면을 이미지로 렌더링합니다. Figma가 없으면 Asana 내용으로 추론해 작성하고 `[추정]`으로 표시합니다.
3. 기존 TC 탭(기본값 `문자전송자격인증`)의 양식과 문체를 예시로 Claude API에 전달해 TC를 생성합니다.
4. 템플릿 탭을 복제해 새 탭을 만들고 TC를 작성합니다. 서식, Result 드롭다운, 목차 링크는 그대로 유지됩니다.
5. `List` 탭의 빈 번호 행에 **기능명(새 탭으로 이동하는 링크)과 Asana 링크**를 등록합니다.
6. 기획 확인이 필요한 사항을 화면에 따로 보여줍니다.

> 테스트 계정 ID/PW나 API 키처럼 댓글에 적힌 비밀 정보는 TC에 옮겨 적지 않도록 프롬프트에 지정되어 있습니다.

---

## 1. exe 받기

### 방법 A. GitHub Actions로 자동 빌드 (권장)
1. 이 폴더를 **Private** 저장소로 GitHub에 올립니다. 사내 업무용이므로 Public은 피해 주세요.
2. 저장소의 **Actions → Build Windows EXE → Run workflow**를 실행합니다.
3. 3~5분 뒤 실행 결과 하단 **Artifacts**에서 `QA-TC-Generator`를 내려받으면 exe가 들어 있습니다.
4. `v1.0.0`처럼 태그를 올리면 **Releases**에 exe가 자동으로 첨부됩니다.

```bash
git init
git add .
git commit -m "QA TC Generator"
git branch -M main
git remote add origin https://github.com/<계정>/qa-tc-generator.git
git push -u origin main
git tag v1.0.0 && git push origin v1.0.0
```

### 방법 B. 내 PC에서 직접 빌드
Python 3.10 이상을 설치한 뒤 `build.bat`을 더블클릭하면 `dist\QA-TC-Generator.exe`가 생성됩니다.

### 방법 C. 빌드 없이 실행
```bash
pip install -r requirements.txt
python run.py                      # 화면(GUI)
python run.py --cli <Asana 링크>   # 명령줄
```

---

## 2. 최초 1회 준비물

| 항목 | 발급 위치 | 비고 |
|---|---|---|
| Asana 개인 액세스 토큰 | Asana → 설정 → 앱 → 개발자 앱 → 개인 액세스 토큰 | 내 계정 권한 그대로 읽음 |
| Claude API 키 | console.anthropic.com → API Keys | Enterprise 좌석과 별도 과금 |
| Figma 개인 액세스 토큰 (선택) | Figma → Settings → Security → Personal access tokens | 파일 읽기 권한 |
| Google OAuth 클라이언트 JSON | 아래 절차 참고 | 시트 쓰기용, 내 Google 계정으로 로그인 |

### Google OAuth 클라이언트 만들기 (최초 1회, 약 10분)
1. [Google Cloud Console](https://console.cloud.google.com)에서 프로젝트를 만듭니다.
2. **API 및 서비스 → 라이브러리**에서 **Google Sheets API**를 사용 설정합니다.
3. **OAuth 동의 화면**: 사용자 유형을 **내부(Internal)**로 선택하고 앱 이름만 입력해 저장합니다.
4. **사용자 인증 정보 → 사용자 인증 정보 만들기 → OAuth 클라이언트 ID → 애플리케이션 유형: 데스크톱 앱**을 선택합니다.
5. JSON을 다운로드해 PC에 저장합니다. 프로그램 설정에서 이 파일을 선택합니다.

처음 실행할 때 브라우저가 열리면 회사 Google 계정으로 로그인하고 허용하세요. 이후에는 저장된 토큰을 사용합니다.
회사 정책상 GCP 프로젝트 생성이 막혀 있으면 IT팀에 OAuth 클라이언트 JSON 발급을 요청하세요.

---

## 3. 사용 방법
1. exe를 실행하고 **설정**에서 필수 항목(*)을 입력합니다.
   - TC 스프레드시트 URL: `1. 기능단위 검수` 시트 주소
   - 템플릿 탭 이름: 복제할 양식 탭(기본 `문자전송자격인증`)
   - 목차 탭 이름: 기본 `List`
2. Asana 태스크 링크를 붙여 넣고 **TC 생성**을 누릅니다.
3. 1~3분 뒤 완료되면 **시트 열기**로 결과를 확인하고, 로그의 **기획 확인 필요 사항**을 검토합니다.

설정 파일은 `%APPDATA%\QA-TC-Generator\config.json`에 저장됩니다. 토큰이 평문으로 저장되므로 공용 PC에서는 사용하지 마세요.

---

## 4. 구조
```
run.py                   진입점 (GUI / --cli)
tcgen/
  app.py                 Tkinter 화면, 설정 창
  pipeline.py            전체 흐름 (시트 연결 → Asana → Figma → Claude → 시트 작성)
  asana.py               태스크·댓글·첨부 수집
  figma.py               Figma 노드 트리 → 텍스트, 화면 PNG 렌더링
  generator.py           Claude API 호출 (tool use로 JSON 수신, 스트리밍)
  prompts.py             TC 작성 시스템 프롬프트, 출력 스키마  ← 품질 튜닝은 여기
  sheets.py              템플릿 탭 복제, TC 쓰기, List 등록
  config.py              설정 저장/로드
.github/workflows/build-exe.yml   Windows exe 자동 빌드
build.bat                내 PC에서 exe 빌드
```

### 커스터마이징 포인트
- **TC 품질**: `tcgen/prompts.py`의 `SYSTEM_PROMPT` 커버리지 체크리스트에 팀의 실제 장애 사례와 정책을 추가하세요.
- **양식 열 구성**: 템플릿이 B~N열(NO, Category, Item, Description, Pre-condition, Depth1~3, Expected Result, Importance, Result×2, 비고)이라는 전제로 작성되어 있습니다. 양식이 바뀌면 `sheets.py`의 `tc_rows()`와 `prompts.py`의 스키마를 함께 수정하세요.
- **모델**: 설정의 Claude 모델명을 [모델 문서](https://docs.claude.com/en/docs/about-claude/models)에서 최신 값으로 바꿀 수 있습니다.

## 5. 문제 해결
| 증상 | 원인 / 조치 |
|---|---|
| Asana 인증 실패 | 토큰 만료 또는 오타. 새로 발급해 설정에 입력 |
| `WorksheetNotFound` | 템플릿 탭 또는 List 탭 이름이 설정과 다름 |
| 브라우저 로그인 후 403 | 해당 Google 계정에 시트 편집 권한이 없음 |
| Figma 403 | Figma 토큰 권한 부족 또는 파일 접근 권한 없음. Figma 없이도 동작 |
| "길이 제한에서 잘렸습니다" | 설정의 최대 출력 토큰을 늘림(예: 48000) |
| 사내망에서 연결 실패 | 프록시 환경이면 `HTTPS_PROXY` 환경변수를 설정 |
